-- phpMyAdmin SQL Dump
-- version 4.3.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 02 2015 г., 10:14
-- Версия сервера: 5.5.34
-- Версия PHP: 5.4.25

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `files_archive`
--

-- --------------------------------------------------------

--
-- Структура таблицы `data_history`
--

DROP TABLE IF EXISTS `data_history`;
CREATE TABLE IF NOT EXISTS `data_history` (
`id` bigint(20) unsigned NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `data` longtext NOT NULL,
  `edit_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `data_history`
--

INSERT INTO `data_history` (`id`, `table_name`, `item_id`, `data`, `edit_time`) VALUES
(1, 'users', 1, 'O:8:"stdClass":8:{s:2:"id";s:1:"1";s:5:"login";s:4:"Nick";s:8:"password";s:32:"202cb962ac59075b964b07152d234b70";s:10:"first_name";s:6:"!Nick!";s:9:"last_name";s:7:"Kovenko";s:5:"email";s:12:"test@mail.ru";s:3:"tel";N;s:10:"birth_date";N;}', '2015-02-28 16:34:01'),
(2, 'users', 1, 'O:8:"stdClass":8:{s:2:"id";s:1:"1";s:5:"login";s:4:"Nick";s:8:"password";s:32:"202cb962ac59075b964b07152d234b70";s:10:"first_name";s:7:"!Nick!!";s:9:"last_name";s:7:"Kovenko";s:5:"email";s:12:"test@mail.ru";s:3:"tel";N;s:10:"birth_date";N;}', '2015-02-28 16:34:27'),
(3, 'users', 1, 'O:8:"stdClass":8:{s:2:"id";s:1:"1";s:5:"login";s:4:"Nick";s:8:"password";s:32:"202cb962ac59075b964b07152d234b70";s:10:"first_name";s:9:"!Nick!!!!";s:9:"last_name";s:7:"Kovenko";s:5:"email";s:12:"test@mail.ru";s:3:"tel";N;s:10:"birth_date";N;}', '2015-02-28 16:35:28'),
(4, 'users', 17, 'O:8:"stdClass":8:{s:2:"id";s:2:"17";s:5:"login";s:5:"admin";s:8:"password";s:32:"202cb962ac59075b964b07152d234b70";s:10:"first_name";s:26:"Администратор";s:9:"last_name";s:8:"Тест";s:5:"email";s:12:"test@mail.ru";s:3:"tel";N;s:10:"birth_date";N;}', '2015-02-28 16:38:21'),
(5, 'users', 1, 'O:8:"stdClass":8:{s:2:"id";s:1:"1";s:5:"login";s:4:"Nick";s:8:"password";s:32:"202cb962ac59075b964b07152d234b70";s:10:"first_name";s:4:"Nick";s:9:"last_name";s:7:"Kovenko";s:5:"email";s:12:"test@mail.ru";s:3:"tel";N;s:10:"birth_date";N;}', '2015-03-02 08:13:02'),
(6, 'users', 1, 'O:8:"stdClass":8:{s:2:"id";s:1:"1";s:5:"login";s:4:"Nick";s:8:"password";s:32:"202cb962ac59075b964b07152d234b70";s:10:"first_name";s:4:"Nick";s:9:"last_name";s:8:"Kovenko!";s:5:"email";s:12:"test@mail.ru";s:3:"tel";N;s:10:"birth_date";N;}', '2015-03-02 08:13:08');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `tel` varchar(32) DEFAULT NULL,
  `birth_date` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `first_name`, `last_name`, `email`, `tel`, `birth_date`) VALUES
(1, 'Nick', '202cb962ac59075b964b07152d234b70', 'Nick', 'Kovenko', 'test@mail.ru', NULL, NULL),
(16, 'test', '202cb962ac59075b964b07152d234b70', 'test', 'test', 'test@mail.ru', '22-22-22', '2010-01-31'),
(17, 'admin', '202cb962ac59075b964b07152d234b70', 'Администратор!', 'Тест', 'test@mail.ru', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `user_files`
--

DROP TABLE IF EXISTS `user_files`;
CREATE TABLE IF NOT EXISTS `user_files` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `file_name` varchar(255) NOT NULL DEFAULT '',
  `file` varchar(255) NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_files`
--

INSERT INTO `user_files` (`id`, `user_id`, `file_name`, `file`, `add_time`, `deleted`) VALUES
(1, 1, '__pyatnitso.jpg', '__pyatnitso.jpg', '2015-03-02 08:03:15', 0),
(2, 1, '5G0rQ5_imsA.jpg', '5G0rQ5_imsA.jpg', '2015-03-02 08:03:15', 1),
(3, 1, '323_v1.png', '323_v1.png', '2015-03-02 08:03:15', 0),
(4, 1, '404_wallpaper.jpg', '404_wallpaper.jpg', '2015-03-02 08:03:15', 0),
(5, 1, '777faba1a8faf518118dc3999c1dcbba.jpg', '777faba1a8faf518118dc3999c1dcbba.jpg', '2015-03-02 08:03:15', 0),
(6, 1, 'avatar.jpg', 'avatar.jpg', '2015-03-02 08:06:48', 1),
(7, 1, '__pyatnitso.jpg', '__pyatnitso-658.jpg', '2015-03-02 08:12:33', 1),
(8, 1, '404_wallpaper.jpg', '404_wallpaper-910.jpg', '2015-03-02 08:12:33', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `data_history`
--
ALTER TABLE `data_history`
 ADD PRIMARY KEY (`id`), ADD KEY `item_id` (`item_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `user_files`
--
ALTER TABLE `user_files`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `data_history`
--
ALTER TABLE `data_history`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT для таблицы `user_files`
--
ALTER TABLE `user_files`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `user_files`
--
ALTER TABLE `user_files`
ADD CONSTRAINT `user_files_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
